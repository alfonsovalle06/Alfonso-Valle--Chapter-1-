#include <iostream>
#include <string>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include "DescriptiveStats.h"
#include "input.h"

using namespace std;

// Function declaration for the menu
char menuOption();

int main()
{
    DescriptiveStats array;
    fstream datafile;
    int input = 0;
    int size = 0;

    do
    {
        switch (menuOption())
        {
        case '0':  // Exit the program
        {
            exit(0);
        }
        break;

        case '1':  // Set data as Sample or Population
        {
            cout << "\n\t\tData Set Option Is Currently Set For Sample!";
            array.setIsPopulation(inputInteger("\n\t\tSelect The Data Set Option (0-Sample Or 1-Population): ", 0, 1));

            if (array.getIsPopulation() == 0)
            {
                cout << "\n\t\tThe Data Set Will Now Be Set To Sample!";
            }
            else
            {
                cout << "\n\t\tThe Data Set Will Now Be Set To Population!";
            }

            cout << endl;
            system("pause");
        }
        break;

        case '2':  // Input Data (Manual, Random, File)
        {
            array.clear();
            char option1 = inputChar("\n\t\tChoose An Option (M) - Manual, (R) - Random, (F) - File, Or (X) - Return: ", static_cast<string>("MRFX"));

            switch (option1)
            {
            case 'M': // Manual input
            {
                size = inputInteger("\n\t\tSpecify The Size Of The Array: ", 3, 200);
                for (int i = 0; i < size; i++)
                {
                    cout << "\n\t\tPlease Enter Integer " << i + 1 << ": ";
                    array.setInput(inputInteger("", 1, 100));
                }
                array.sortArray();
                cout << "\n\t\tData Set Contains " << size << " Data Point(s)!\n";
                cout << "\t\t[  ";
                for (int i = 0; i < size; i++)
                {
                    cout << array.getInput(i);
                    if (i != size - 1)
                        cout << ", ";
                }
                cout << " ]" << endl;
                system("pause");
            }
            break;

            case 'R':  // Random input
            {
                srand(time(0));
                size = inputInteger("\n\t\tSpecify The Size Of The Array: ", 3, 200);
                for (int i = 0; i < size; i++)
                {
                    array.setInput(rand() % 100 + 1);
                }
                array.sortArray();
                cout << "\n\t\tData Set Contains " << size << " Data Point(s)!\n";
                cout << "\t\t[  ";
                for (int i = 0; i < size; i++)
                {
                    cout << array.getInput(i);
                    if (i != size - 1)
                        cout << ", ";
                }
                cout << " ]" << endl;
                system("pause");
            }
            break;

            case 'F':  // File input
            {
                string fileName = inputString("\n\t\tEnter the name of the file for analysis: ", true);
                datafile.open(fileName, ios::in);
                if (datafile.fail())
                {
                    cout << "\n\t\tSorry this file does not exist! Try again!" << endl;
                    system("pause");
                    break;
                }
                while (!datafile.eof())
                {
                    datafile >> input;
                    array.setInput(input);
                }
                size = array.getSize();
                array.sortArray();
                cout << "\n\t\tData Set Contains " << size << " Data Point(s)!\n";
                cout << "\t\t[  ";
                for (int i = 0; i < size; i++)
                {
                    cout << array.getInput(i);
                    if (i != size - 1)
                        cout << ", ";
                }
                cout << " ]" << endl;
                datafile.close();
                system("pause");
            }
            break;

            case 'X':  // Return
            {
                break;
            }
            }
        }
        break;

        case 'A':  // Find Minimum
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tMinimum: " << array.Findminimum() << endl;
            system("pause");
        }
        break;

        case 'B':  // Find Maximum
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tMaximum: " << array.Findmaximum() << endl;
            system("pause");
        }
        break;

        case 'C':  // Find Range
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tRange: " << array.Findrange() << endl;
            system("pause");
        }
        break;

        case 'D':  // Find Size
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tSize: " << array.getSize() << " Data Points" << endl;
            system("pause");
        }
        break;

        case 'E':  // Find Sum
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tSum: " << array.FindSum() << endl;
            system("pause");
        }
        break;

        case 'F':  // Find Mean
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tMean: " << array.FindMean() << endl;
            system("pause");
        }
        break;

        case 'G':  // Find Median
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tMedian: " << array.FindMedian() << endl;
            system("pause");
        }
        break;

        case 'H':  // Find Mode
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tMode: " << array.FindMode() << endl;
            system("pause");
        }
        break;

        case 'I':  // Find Standard Deviation
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tStandard Deviation: " << array.FindStandardDeviation() << endl;
            system("pause");
        }
        break;

        case 'J':  // Find Variance
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tVariance: " << array.FindVariance() << endl;
            system("pause");
        }
        break;

        case 'K':  // Find Mid Range
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tMid Range: " << array.FindMidRange() << endl;
            system("pause");
        }
        break;

        case 'L':  // Find Quartiles
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tQuartiles: ";
            double* quartPtr = array.FindQuartiles();
            if (quartPtr[0] == NULL)
                cout << "Unknown";
            else {
                cout << "Q1: " << quartPtr[0] << ", Q2 (Median): " << quartPtr[1] << ", Q3: " << quartPtr[2];
            }
            cout << endl;
            system("pause");
        }
        break;

        case 'M':  // Interquartile Range
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tInterquartile Range: " << array.findIQR() << endl;
            system("pause");
        }
        break;

        case 'N':  // Outliers
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            double* outliers = array.FindOutliers();

            if (outliers[0] == NULL && outliers[1] == NULL) {
                cout << "\n\t\tNo outliers found." << endl;
            }
            else {
                cout << "\n\t\tLower Outlier: " << (outliers[0] == 0 ? "None" : to_string(outliers[0])) << endl;
                cout << "\n\t\tUpper Outlier: " << (outliers[1] == 0 ? "None" : to_string(outliers[1])) << endl;
            }

            system("pause");
        }
        break;

        case 'O':  // Sum of Squares
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tSum of Squares: " << array.FindSumOfSquares() << endl;
            system("pause");
        }
        break;

        case 'P':  // Mean Absolute Deviation
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tMean Absolute Deviation: " << array.FindMeanAbsoluteDeviation() << endl;
            system("pause");
        }
        break;

        case 'Q':  // Root Mean Square
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tRoot Mean Square: " << array.FindRootMeanSquare() << endl;
            system("pause");
        }
        break;

        case 'R':  // Standard Error of the Mean
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tStandard Error of the Mean: " << array.FindSTDErrorOfMean() << endl;
            system("pause");
        }
        break;

        case 'S':  // Skewness
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tSkewness: " << array.FindSkewness() << endl;
            system("pause");
        }
        break;

        case 'T':  // Kurtosis
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tKurtosis: " << array.FindKurtosis() << endl;
            system("pause");
        }
        break;

        case 'U':  // Kurtosis Excess
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tKurtosis Excess: " << array.FindKurtosisExcess() << endl;
            system("pause");
        }
        break;

        case 'V':  // Coefficient of Variation
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tCoefficient of Variation: " << array.FindCoefficientOfVariation() << "%" << endl;
            system("pause");
        }
        break;

        case 'W':  // Relative Standard Deviation
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tRelative Standard Deviation: " << array.FindRelativeSTDDeviation() << "%" << endl;
            system("pause");
        }
        break;

        case 'X':  // Frequencies
        {
            if (array.getSize() == 0) {
                cout << "\n\t\tNo data to analyze, go to option 2 and try again!";
                system("pause");
                break;
            }
            cout << "\n\t\tFrequencies: \n" << array.frequencyOfDataSet() << endl;
            system("pause");
        }
        break;

        default:
            cout << "\n\t\tInvalid option! Please try again." << endl;
            system("pause");
            break;
        }

    } while (true);

    return 0;
}


// Function definition for displaying the menu
char menuOption()
{

    system("cls");

    cout << "\n\tDESCRIPTIVE STATISTICS ARE BRIEF DESCRIPTIVE COEFFICIENTS THAT SUMMARIZE A GIVEN DATA SET,";
    cout << "\n\tWHICH CAN BE EITHER A REPRESENTATION OF THE ENTIRE POPULATION OR A SAMPLE OF A POPULATION.";
    cout << "\n\tDESCRIPTIVE STATISTICS ARE BROKEN DOWN INTO MEASURES OF CENTRAL TENDENCY AND MEASURE OF";
    cout << "\n\tVARIABILITY(SPREAD). MEASURES OF CENTRAL TENDENCY INCLUDE THE MEAN, THE MEDIAN, AND MODE. WHILE";
    cout << "\n\tMEASURES OF VARIABILITY INCLUDE STANDARD DEVIATION, VARIANCE, MINIMUM, AND MAXIMUM VARIABLES,";
    cout << "\n\tKURTOSIS, AND SKEWNESS";

    cout << "\n";

    cout << "\n\tCMPR131 - CHAPTER 1: DESCRIPTIVE STATISTICS - BY - OSCAR GALLARDO - BRISSA HOKE - ALFONSO VALLE - (10/23/2024)";
    cout << "\n\t" << string(110, char(205));
    cout << "\n\t\t1> Select Data Set Option";
    cout << "\n\t\t2> Select Data Input Option, Store Data Into A Sorted Array & Display The Data Set";
    cout << "\n\t" << string(110, char(205));
    cout << "\n\t\tA> Minimum                                        M> Interquartile Range";
    cout << "\n\t\tB> Maximum                                        N> Outlier";
    cout << "\n\t\tC> Range                                          O> Sum of Squares";
    cout << "\n\t\tD> Size                                           P> Mean Absolute Deviation";
    cout << "\n\t\tE> Sum                                            Q> Root Mean Square";
    cout << "\n\t\tF> Mean                                           R> STD Error Of The Mean";
    cout << "\n\t\tG> Median                                         S> Skewness";
    cout << "\n\t\tH> Mode                                           T> Kurtosis";
    cout << "\n\t\tI> Standard Deviation                             U> Kurtosis Excess";
    cout << "\n\t\tJ> Variance                                       V> Coefficient of Variation";
    cout << "\n\t\tK> Mid Range                                      W> Relative Standard Deviation";
    cout << "\n\t\tL> Quartile                                       X> Frequencies";
    cout << "\n\t" << string(110, char(205));
    cout << "\n\t\t3> DISPLAY ALL RESULTS(OPTION A....X) AND WRITE OUT TO A TEXTFILE";
    cout << "\n\t" << string(110, char(205));
    cout << "\n\t\t0> EXIT";
    cout << "\n\t" << string(110, char(205));


    return inputChar("\n\t\tOPTION: ", static_cast<string>("0123ABCDEFGHIJKLMNOPQRSTUVWX"));

    system("pause");

}
// Global pause function
void pause()
{
    cout << "\n\tPress Enter to continue...";
    cin.ignore(); // To consume any leftover input in the buffer
    cin.get();    // Waits for the user to press Enter
}
