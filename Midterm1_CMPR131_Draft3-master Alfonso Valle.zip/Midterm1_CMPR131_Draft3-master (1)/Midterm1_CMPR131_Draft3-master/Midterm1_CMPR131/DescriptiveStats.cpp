#include "DescriptiveStats.h"
#include <cmath>
#include <map>
#include <fstream>
#include <algorithm>
#include <iomanip>

using namespace std;

DescriptiveStats::DescriptiveStats() {
    size = 0;
    isPopulation = false;
    array = new int[MAX_SIZE];  // Dynamically allocate memory for array
}

DescriptiveStats::~DescriptiveStats() {
    delete[] array;  // Free the dynamically allocated memory
}

int DescriptiveStats::getSize() const {
    return size;
}

void DescriptiveStats::setIsPopulation(int ifIsPopulation) {
    isPopulation = (ifIsPopulation == 1);
}

bool DescriptiveStats::getIsPopulation() const {
    return isPopulation;
}

void DescriptiveStats::setInput(int newInput) {
    if (size < MAX_SIZE) {
        array[size++] = newInput;  // Insert new input and increment size
    }
}

int DescriptiveStats::getInput(int index) const {
    return (index >= 0 && index < size) ? array[index] : -1;  // Return input at specific index
}

void DescriptiveStats::clear() {
    delete[] array;  // Free the old array memory
    array = new int[MAX_SIZE];  // Reallocate new memory for array
    size = 0;  // Reset size
}

int DescriptiveStats::Findminimum() const {
    int minNumber = *array;  // Initialize with the first element
    for (int i = 1; i < size; i++) {
        if (array[i] < minNumber) {
            minNumber = array[i];  // Update if a smaller number is found
        }
    }
    return minNumber;
}

int DescriptiveStats::Findmaximum() const {
    int maxNumber = *array;  // Initialize with the first element
    for (int i = 1; i < size; i++) {
        if (array[i] > maxNumber) {
            maxNumber = array[i];  // Update if a larger number is found
        }
    }
    return maxNumber;
}

int DescriptiveStats::Findrange() const {
    return Findmaximum() - Findminimum();  // Return the range
}

int DescriptiveStats::FindSum() const {
    int sum = 0;
    for (int i = 0; i < size; i++) {
        sum += array[i];
    }
    return sum;
}

double DescriptiveStats::FindMean() const {
    return static_cast<double>(FindSum()) / size;  // Return mean
}

double DescriptiveStats::FindMedian() const {
    int* tempArray = new int[size];
    copy(array, array + size, tempArray);  // Copy the array for sorting
    sort(tempArray, tempArray + size);  // Sort the copied array

    double median;
    if (size % 2 == 0) {  // If even number of elements
        median = (tempArray[size / 2 - 1] + tempArray[size / 2]) / 2.0;
    } else {  // If odd number of elements
        median = tempArray[size / 2];
    }

    delete[] tempArray;  // Free the temporary array memory
    return median;
}

string DescriptiveStats::FindMode() const {
    map<int, int> frequencyMap;
    for (int i = 0; i < size; i++) {
        frequencyMap[array[i]]++;  // Count the frequency of each number
    }

    int maxFreq = 0;
    int modeValue = array[0];
    for (auto it : frequencyMap) {
        if (it.second > maxFreq) {
            maxFreq = it.second;
            modeValue = it.first;
        }
    }

    if (maxFreq == 1) {
        return "No mode";  // All values occur only once
    }

    return to_string(modeValue);
}

double DescriptiveStats::FindStandardDeviation() const {
    double mean = FindMean();
    double sumSqDiff = 0;
    for (int i = 0; i < size; i++) {
        sumSqDiff += pow(array[i] - mean, 2);
    }
    if (isPopulation) {
        return sqrt(sumSqDiff / size);  // Population standard deviation
    }
    return sqrt(sumSqDiff / (size - 1));  // Sample standard deviation
}

double DescriptiveStats::FindVariance() const {
    return pow(FindStandardDeviation(), 2);  // Variance is SD squared
}

void DescriptiveStats::sortArray() {
    sort(array, array + size);  // Sort the main array
}

double DescriptiveStats::FindMidRange() const {
    return (Findminimum() + Findmaximum()) / 2.0;
}

double DescriptiveStats::FindSumOfSquares() const {
    double mean = FindMean();
    double sumOfSquares = 0;
    for (int i = 0; i < size; i++) {
        sumOfSquares += pow(array[i] - mean, 2);
    }
    return sumOfSquares;
}

double DescriptiveStats::FindMeanAbsoluteDeviation() const {
    double mean = FindMean();
    double mad = 0;
    for (int i = 0; i < size; i++) {
        mad += abs(array[i] - mean);
    }
    return mad / size;
}

double DescriptiveStats::FindRootMeanSquare() const {
    double sumOfSquares = 0;
    for (int i = 0; i < size; i++) {
        sumOfSquares += pow(array[i], 2);
    }
    return sqrt(sumOfSquares / size);
}

double DescriptiveStats::FindSTDErrorOfMean() const {
    return FindStandardDeviation() / sqrt(size);
}

double DescriptiveStats::FindSkewness() const {
    double mean = FindMean();
    double stdDev = FindStandardDeviation();
    double skewness = 0;
    for (int i = 0; i < size; i++) {
        skewness += pow((array[i] - mean) / stdDev, 3);
    }
    return skewness / size;
}

double DescriptiveStats::FindKurtosis() const {
    double mean = FindMean();
    double stdDev = FindStandardDeviation();
    double kurtosis = 0;
    for (int i = 0; i < size; i++) {
        kurtosis += pow((array[i] - mean) / stdDev, 4);
    }
    return kurtosis / size - 3;  // Excess kurtosis
}

double DescriptiveStats::FindKurtosisExcess() const {
    return FindKurtosis();
}

double DescriptiveStats::FindCoefficientOfVariation() const {
    return (FindStandardDeviation() / FindMean()) * 100;
}

double DescriptiveStats::FindRelativeSTDDeviation() const {
    return FindCoefficientOfVariation();  // Relative SD is the same as CoV
}

double* DescriptiveStats::FindQuartiles() const {
    double* quartiles = new double[3];  // Dynamically allocate space for quartiles
    int* tempArray = new int[size];
    copy(array, array + size, tempArray);
    sort(tempArray, tempArray + size);

    quartiles[1] = FindMedian();  // Q2 (Median)
    
    if (size % 2 == 0) {  // For even-sized arrays
        DescriptiveStats lowerHalf, upperHalf;
        for (int i = 0; i < size / 2; i++) {
            lowerHalf.setInput(tempArray[i]);
        }
        for (int i = size / 2; i < size; i++) {
            upperHalf.setInput(tempArray[i]);
        }
        quartiles[0] = lowerHalf.FindMedian();  // Q1
        quartiles[2] = upperHalf.FindMedian();  // Q3
    } else {  // For odd-sized arrays
        DescriptiveStats lowerHalf, upperHalf;
        for (int i = 0; i < size / 2; i++) {
            lowerHalf.setInput(tempArray[i]);
        }
        for (int i = (size / 2) + 1; i < size; i++) {
            upperHalf.setInput(tempArray[i]);
        }
        quartiles[0] = lowerHalf.FindMedian();  // Q1
        quartiles[2] = upperHalf.FindMedian();  // Q3
    }

    delete[] tempArray;
    return quartiles;
}

double DescriptiveStats::findIQR() const {
    double* quartiles = FindQuartiles();
    double IQR = quartiles[2] - quartiles[0];  // IQR = Q3 - Q1
    delete[] quartiles;  // Free memory for quartiles
    return IQR;
}

double* DescriptiveStats::FindOutliers() const {
    double IQR = findIQR();
    double* outliers = new double[size];
    int outlierCount = 0;

    double* quartiles = FindQuartiles();
    double lowerBound = quartiles[0] - 1.5 * IQR;
    double upperBound = quartiles[2] + 1.5 * IQR;
    delete[] quartiles;

    for (int i = 0; i < size; i++) {
        if (array[i] < lowerBound || array[i] > upperBound) {
            outliers[outlierCount++] = array[i];  // Add outliers
        }
    }

    if (outlierCount == 0) {
        delete[] outliers;  // No outliers found, free memory
        return nullptr;
    }

    double* resultOutliers = new double[outlierCount];
    copy(outliers, outliers + outlierCount, resultOutliers);  // Copy to final outliers array
    delete[] outliers;
    return resultOutliers;
}

string DescriptiveStats::frequencyOfDataSet() const {
    map<int, int> freqMap;
    for (int i = 0; i < size; i++) {
        freqMap[array[i]]++;
    }

    string result = "\n\n\t\tFrequency Table: \n";
    result += "\t\tVALUE: \t\tFREQUENCY:\t\tFREQUENCY %:\n";
    result += "\t\t" + string(60, '=') + "\n";

    for (auto& entry : freqMap) {
        result += "\t\t" + to_string(entry.first) + " \t\t\t " + to_string(entry.second) +
                  " \t\t\t" + to_string(static_cast<float>(entry.second) / size * 100) + "%\n";
    }

    return result;
}

void DescriptiveStats::printDataToFile(string fileName) const {
    ofstream outFile(fileName);
    if (outFile.is_open()) {
        outFile << *this;
        outFile.close();
    }
}

ostream& DescriptiveStats::displayArray(ostream& out) const {
    out << "[ ";
    for (int i = 0; i < size; i++) {
        out << array[i];
        if (i != size - 1) out << ", ";
    }
    out << " ]\n";
    return out;
}

ostream& operator<<(ostream& out, const DescriptiveStats& obj) {
    out << "\nData set contains " << obj.size << " data points:\n";
    obj.displayArray(out);

    // Output statistics
    out << "\nMinimum: " << obj.Findminimum();
    out << "\nMaximum: " << obj.Findmaximum();
    out << "\nRange: " << obj.Findrange();
    out << "\nMean: " << obj.FindMean();
    out << "\nMedian: " << obj.FindMedian();
    out << "\nMode: " << obj.FindMode();
    out << "\nStandard Deviation: " << obj.FindStandardDeviation();
    out << "\nVariance: " << obj.FindVariance();
    out << "\nMid Range: " << obj.FindMidRange();
    out << "\nSum of Squares: " << obj.FindSumOfSquares();
    out << "\nMean Absolute Deviation: " << obj.FindMeanAbsoluteDeviation();
    out << "\nRoot Mean Square: " << obj.FindRootMeanSquare();
    out << "\nStandard Error of Mean: " << obj.FindSTDErrorOfMean();
    out << "\nSkewness: " << obj.FindSkewness();
    out << "\nKurtosis: " << obj.FindKurtosis();
    out << "\nKurtosis Excess: " << obj.FindKurtosisExcess();
    out << "\nCoefficient of Variation: " << obj.FindCoefficientOfVariation();
    out << "\nRelative Standard Deviation: " << obj.FindRelativeSTDDeviation() << "%";

    double* quartiles = obj.FindQuartiles();
    out << "\nQuartiles: Q1 = " << quartiles[0] << ", Q2 = " << quartiles[1] << ", Q3 = " << quartiles[2];
    delete[] quartiles;

    out << "\nInterquartile Range (IQR): " << obj.findIQR();

    double* outliers = obj.FindOutliers();
    if (outliers != nullptr) {
        out << "\nOutliers: [ ";
        for (int i = 0; outliers[i] != '\0'; i++) {
            out << outliers[i];
            if (outliers[i + 1] != '\0') out << ", ";
        }
        out << " ]";
        delete[] outliers;
    } else {
        out << "\nOutliers: None";
    }

    out << obj.frequencyOfDataSet();

    return out;
}
